import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DhikrCounterScreen extends StatefulWidget {
  const DhikrCounterScreen({Key? key}) : super(key: key);

  @override
  State<DhikrCounterScreen> createState() => _DhikrCounterScreenState();
}

class _DhikrCounterScreenState extends State<DhikrCounterScreen> {
  final List<DhikrCounter> _counters = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadCounters();
  }

  Future<void> _loadCounters() async {
    try {
      setState(() {
        _isLoading = true;
      });

      final prefs = await SharedPreferences.getInstance();
      final countersJson = prefs.getStringList('dhikr_counters') ?? [];
      
      if (countersJson.isEmpty) {
        // Add default counters if none exist
        _counters.addAll([
          DhikrCounter(
            id: '1',
            name: 'Subhanallah',
            arabicText: 'سبحان الله',
            target: 33,
            count: 0,
          ),
          DhikrCounter(
            id: '2',
            name: 'Alhamdulillah',
            arabicText: 'الحمد لله',
            target: 33,
            count: 0,
          ),
          DhikrCounter(
            id: '3',
            name: 'Allahu Akbar',
            arabicText: 'الله أكبر',
            target: 34,
            count: 0,
          ),
          DhikrCounter(
            id: '4',
            name: 'La ilaha illallah',
            arabicText: 'لا إله إلا الله',
            target: 100,
            count: 0,
          ),
          DhikrCounter(
            id: '5',
            name: 'Astaghfirullah',
            arabicText: 'أستغفر الله',
            target: 100,
            count: 0,
          ),
        ]);
        await _saveCounters();
      } else {
        _counters.clear();
        for (final json in countersJson) {
          _counters.add(DhikrCounter.fromJson(json));
        }
      }

      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      print('Error loading counters: $e');
    }
  }

  Future<void> _saveCounters() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final countersJson = _counters.map((counter) => counter.toJson()).toList();
      await prefs.setStringList('dhikr_counters', countersJson);
    } catch (e) {
      print('Error saving counters: $e');
    }
  }

  Future<void> _incrementCounter(int index) async {
    setState(() {
      _counters[index].count++;
    });
    await _saveCounters();
  }

  Future<void> _resetCounter(int index) async {
    setState(() {
      _counters[index].count = 0;
    });
    await _saveCounters();
  }

  Future<void> _addNewCounter() async {
    final result = await showDialog<DhikrCounter>(
      context: context,
      builder: (context) => _AddDhikrDialog(),
    );

    if (result != null) {
      setState(() {
        _counters.add(result);
      });
      await _saveCounters();
    }
  }

  Future<void> _editCounter(int index) async {
    final result = await showDialog<DhikrCounter>(
      context: context,
      builder: (context) => _AddDhikrDialog(counter: _counters[index]),
    );

    if (result != null) {
      setState(() {
        _counters[index] = result;
      });
      await _saveCounters();
    }
  }

  Future<void> _deleteCounter(int index) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Dhikr Counter'),
        content: Text('Are you sure you want to delete "${_counters[index].name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() {
        _counters.removeAt(index);
      });
      await _saveCounters();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('DhikrMatic Counter'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _addNewCounter,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _counters.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('No dhikr counters available'),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _addNewCounter,
                        child: const Text('Add Counter'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _counters.length,
                  itemBuilder: (context, index) {
                    final counter = _counters[index];
                    final progress = counter.count / counter.target;
                    
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        counter.name,
                                        style: Theme.of(context).textTheme.titleLarge,
                                      ),
                                      Text(
                                        counter.arabicText,
                                        style: const TextStyle(
                                          fontSize: 20,
                                          fontFamily: 'Amiri',
                                        ),
                                        textDirection: TextDirection.rtl,
                                      ),
                                    ],
                                  ),
                                ),
                                PopupMenuButton<String>(
                                  onSelected: (value) {
                                    if (value == 'edit') {
                                      _editCounter(index);
                                    } else if (value == 'delete') {
                                      _deleteCounter(index);
                                    } else if (value == 'reset') {
                                      _resetCounter(index);
                                    }
                                  },
                                  itemBuilder: (context) => [
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Text('Edit'),
                                    ),
                                    const PopupMenuItem(
                                      value: 'reset',
                                      child: Text('Reset'),
                                    ),
                                    const PopupMenuItem(
                                      value: 'delete',
                                      child: Text('Delete'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            LinearProgressIndicator(
                              value: progress > 1 ? 1 : progress,
                              minHeight: 8,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '${counter.count} / ${counter.target}',
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                            const SizedBox(height: 16),
                            SizedBox(
                              width: double.infinity,
                              height: 80,
                              child: ElevatedButton(
                                onPressed: () => _incrementCounter(index),
                                style: ElevatedButton.styleFrom(
                                  shape: const CircleBorder(),
                                ),
                                child: Text(
                                  counter.count.toString(),
                                  style: const TextStyle(
                                    fontSize: 32,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

class DhikrCounter {
  final String id;
  final String name;
  final String arabicText;
  final int target;
  int count;

  DhikrCounter({
    required this.id,
    required this.name,
    required this.arabicText,
    required this.target,
    this.count = 0,
  });

  factory DhikrCounter.fromJson(String json) {
    final parts = json.split('|');
    return DhikrCounter(
      id: parts[0],
      name: parts[1],
      arabicText: parts[2],
      target: int.parse(parts[3]),
      count: int.parse(parts[4]),
    );
  }

  String toJson() {
    return '$id|$name|$arabicText|$target|$count';
  }
}

class _AddDhikrDialog extends StatefulWidget {
  final DhikrCounter? counter;

  const _AddDhikrDialog({this.counter});

  @override
  State<_AddDhikrDialog> createState() => _AddDhikrDialogState();
}

class _AddDhikrDialogState extends State<_AddDhikrDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _arabicTextController = TextEditingController();
  final _targetController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.counter != null) {
      _nameController.text = widget.counter!.name;
      _arabicTextController.text = widget.counter!.arabicText;
      _targetController.text = widget.counter!.target.toString();
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _arabicTextController.dispose();
    _targetController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.counter == null ? 'Add Dhikr Counter' : 'Edit Dhikr Counter'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Name',
                  hintText: 'e.g., Subhanallah',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a name';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _arabicTextController,
                decoration: const InputDecoration(
                  labelText: 'Arabic Text',
                  hintText: 'e.g., سبحان الله',
                ),
                textDirection: TextDirection.rtl,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter Arabic text';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _targetController,
                decoration: const InputDecoration(
                  labelText: 'Target Count',
                  hintText: 'e.g., 33',
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a target count';
                  }
                  if (int.tryParse(value) == null || int.parse(value) <= 0) {
                    return 'Please enter a valid number';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              final counter = DhikrCounter(
                id: widget.counter?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
                name: _nameController.text,
                arabicText: _arabicTextController.text,
                target: int.parse(_targetController.text),
                count: widget.counter?.count ?? 0,
              );
              Navigator.of(context).pop(counter);
            }
          },
          child: const Text('Save'),
        ),
      ],
    );
  }
}
