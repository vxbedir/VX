import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../services/qibla_service.dart';

class QiblaScreen extends StatefulWidget {
  const QiblaScreen({Key? key}) : super(key: key);

  @override
  State<QiblaScreen> createState() => _QiblaScreenState();
}

class _QiblaScreenState extends State<QiblaScreen> {
  final QiblaService _qiblaService = QiblaService();
  double _direction = 0;
  bool _hasError = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _initQiblaDirection();
  }

  Future<void> _initQiblaDirection() async {
    try {
      _qiblaService.qiblaStream.listen(
        (direction) {
          setState(() {
            _direction = direction;
            _hasError = false;
          });
        },
        onError: (error) {
          setState(() {
            _hasError = true;
            _errorMessage = error.toString();
          });
        },
      );
    } catch (e) {
      setState(() {
        _hasError = true;
        _errorMessage = 'Error initializing compass: $e';
      });
    }
  }

  @override
  void dispose() {
    _qiblaService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Qibla Direction'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              _qiblaService.updateLocation();
            },
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_hasError) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Error: $_errorMessage',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _initQiblaDirection,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        const SizedBox(height: 20),
        Text(
          'Point the top of your device toward the Kaaba',
          style: Theme.of(context).textTheme.titleMedium,
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 20),
        Expanded(
          child: Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Compass background
                Container(
                  width: 300,
                  height: 300,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    shape: BoxShape.circle,
                  ),
                  child: CustomPaint(
                    painter: CompassPainter(),
                  ),
                ),
                // Rotating needle with Kaaba image
                Transform.rotate(
                  angle: _direction * (math.pi / 180) * -1,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Kaaba image at the tip
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Center(
                          child: Text(
                            'Kaaba',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                            ),
                          ),
                        ),
                      ),
                      // Needle
                      Container(
                        width: 4,
                        height: 120,
                        color: Colors.red,
                      ),
                    ],
                  ),
                ),
                // Center dot
                Container(
                  width: 10,
                  height: 10,
                  decoration: const BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(20.0),
          child: Text(
            'Direction: ${_direction.toStringAsFixed(1)}°',
            style: Theme.of(context).textTheme.titleLarge,
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}

class CompassPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    
    // Draw compass markings
    final paint = Paint()
      ..color = Colors.black
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    
    canvas.drawCircle(center, radius, paint);
    
    // Draw cardinal directions
    final textPainter = TextPainter(
      textDirection: TextDirection.ltr,
    );
    
    // North
    textPainter.text = const TextSpan(
      text: 'N',
      style: TextStyle(color: Colors.red, fontSize: 20, fontWeight: FontWeight.bold),
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(center.dx - textPainter.width / 2, center.dy - radius + 20));
    
    // East
    textPainter.text = const TextSpan(
      text: 'E',
      style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(center.dx + radius - textPainter.width - 20, center.dy - textPainter.height / 2));
    
    // South
    textPainter.text = const TextSpan(
      text: 'S',
      style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(center.dx - textPainter.width / 2, center.dy + radius - textPainter.height - 20));
    
    // West
    textPainter.text = const TextSpan(
      text: 'W',
      style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(center.dx - radius + 20, center.dy - textPainter.height / 2));
    
    // Draw degree markings
    for (int i = 0; i < 360; i += 15) {
      final angle = i * (math.pi / 180);
      final outerPoint = Offset(
        center.dx + (radius - 10) * math.cos(angle),
        center.dy + (radius - 10) * math.sin(angle),
      );
      final innerPoint = Offset(
        center.dx + (radius - 20) * math.cos(angle),
        center.dy + (radius - 20) * math.sin(angle),
      );
      
      canvas.drawLine(innerPoint, outerPoint, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
