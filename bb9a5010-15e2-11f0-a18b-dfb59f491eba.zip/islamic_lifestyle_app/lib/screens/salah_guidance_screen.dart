import 'package:flutter/material.dart';

class SalahGuidanceScreen extends StatefulWidget {
  const SalahGuidanceScreen({Key? key}) : super(key: key);

  @override
  State<SalahGuidanceScreen> createState() => _SalahGuidanceScreenState();
}

class _SalahGuidanceScreenState extends State<SalahGuidanceScreen> {
  final List<PrayerStep> _prayerSteps = [
    PrayerStep(
      title: 'Intention (Niyyah)',
      arabicText: 'النية',
      description: 'Stand facing the Qibla and make the intention to pray. The intention is made in the heart and does not need to be spoken.',
      imageAsset: 'assets/images/prayer/standing.png',
      audioAsset: 'assets/audio/prayer/niyyah.mp3',
    ),
    PrayerStep(
      title: 'Takbir (Allahu Akbar)',
      arabicText: 'الله أكبر',
      description: 'Raise your hands to your ears and say "Allahu Akbar" (Allah is the Greatest).',
      imageAsset: 'assets/images/prayer/takbir.png',
      audioAsset: 'assets/audio/prayer/takbir.mp3',
    ),
    PrayerStep(
      title: 'Qiyam (Standing)',
      arabicText: 'القيام',
      description: 'Place your right hand over your left hand on your chest. Recite the opening supplication (Subhanaka), followed by Surah Al-Fatiha and another short Surah or verses from the Quran.',
      imageAsset: 'assets/images/prayer/qiyam.png',
      audioAsset: 'assets/audio/prayer/fatiha.mp3',
    ),
    PrayerStep(
      title: 'Ruku (Bowing)',
      arabicText: 'الركوع',
      description: 'Say "Allahu Akbar" and bow down with your back straight and hands on your knees. Say "Subhana Rabbiyal Azeem" (Glory be to my Lord, the Most Great) three times.',
      imageAsset: 'assets/images/prayer/ruku.png',
      audioAsset: 'assets/audio/prayer/ruku.mp3',
    ),
    PrayerStep(
      title: 'Qiyam (Standing after Ruku)',
      arabicText: 'القيام بعد الركوع',
      description: 'Rise from bowing and say "Sami Allahu liman hamidah, Rabbana lakal hamd" (Allah hears those who praise Him. Our Lord, praise be to You).',
      imageAsset: 'assets/images/prayer/standing_after_ruku.png',
      audioAsset: 'assets/audio/prayer/sami_allah.mp3',
    ),
    PrayerStep(
      title: 'Sujud (Prostration)',
      arabicText: 'السجود',
      description: 'Say "Allahu Akbar" and prostrate with your forehead, nose, palms, knees, and toes touching the ground. Say "Subhana Rabbiyal Ala" (Glory be to my Lord, the Most High) three times.',
      imageAsset: 'assets/images/prayer/sujud.png',
      audioAsset: 'assets/audio/prayer/sujud.mp3',
    ),
    PrayerStep(
      title: 'Jalsah (Sitting between Prostrations)',
      arabicText: 'الجلسة بين السجدتين',
      description: 'Say "Allahu Akbar" and sit up. Say "Rabbi ighfir li" (My Lord, forgive me).',
      imageAsset: 'assets/images/prayer/jalsah.png',
      audioAsset: 'assets/audio/prayer/jalsah.mp3',
    ),
    PrayerStep(
      title: 'Second Sujud (Prostration)',
      arabicText: 'السجدة الثانية',
      description: 'Say "Allahu Akbar" and prostrate again as before. Say "Subhana Rabbiyal Ala" three times.',
      imageAsset: 'assets/images/prayer/sujud.png',
      audioAsset: 'assets/audio/prayer/sujud.mp3',
    ),
    PrayerStep(
      title: 'Tashahhud (Sitting for Testimony)',
      arabicText: 'التشهد',
      description: 'Sit and recite the Tashahhud: "At-tahiyyatu lillahi... (All greetings are for Allah...)"',
      imageAsset: 'assets/images/prayer/tashahhud.png',
      audioAsset: 'assets/audio/prayer/tashahhud.mp3',
    ),
    PrayerStep(
      title: 'Tasleem (Concluding the Prayer)',
      arabicText: 'التسليم',
      description: 'Turn your head to the right and say "Assalamu alaikum wa rahmatullah" (Peace and mercy of Allah be upon you), then to the left and repeat the same.',
      imageAsset: 'assets/images/prayer/tasleem.png',
      audioAsset: 'assets/audio/prayer/tasleem.mp3',
    ),
  ];

  int _currentStep = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Salah Guidance'),
      ),
      body: Column(
        children: [
          _buildStepIndicator(),
          Expanded(
            child: _buildCurrentStep(),
          ),
          _buildNavigationButtons(),
        ],
      ),
    );
  }

  Widget _buildStepIndicator() {
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _prayerSteps.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              setState(() {
                _currentStep = index;
              });
            },
            child: Container(
              width: 40,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _currentStep == index
                    ? Theme.of(context).primaryColor
                    : Colors.grey[300],
              ),
              child: Center(
                child: Text(
                  (index + 1).toString(),
                  style: TextStyle(
                    color: _currentStep == index ? Colors.white : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCurrentStep() {
    final step = _prayerSteps[_currentStep];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            step.title,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            step.arabicText,
            style: const TextStyle(
              fontSize: 28,
              fontFamily: 'Amiri',
            ),
            textDirection: TextDirection.rtl,
          ),
          const SizedBox(height: 16),
          // Placeholder for image (in a real app, this would be an actual image)
          Container(
            height: 200,
            width: double.infinity,
            color: Colors.grey[300],
            child: Center(
              child: Text(
                'Prayer Position Image\n(${step.imageAsset})',
                textAlign: TextAlign.center,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            step.description,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          const SizedBox(height: 24),
          // Audio player (simplified for this example)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey[200],
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.play_arrow),
                  onPressed: () {
                    // TODO: Implement audio playback
                  },
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Audio Pronunciation',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      Text(
                        step.audioAsset,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ElevatedButton(
            onPressed: _currentStep > 0
                ? () {
                    setState(() {
                      _currentStep--;
                    });
                  }
                : null,
            child: const Text('Previous'),
          ),
          Text(
            '${_currentStep + 1} / ${_prayerSteps.length}',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          ElevatedButton(
            onPressed: _currentStep < _prayerSteps.length - 1
                ? () {
                    setState(() {
                      _currentStep++;
                    });
                  }
                : null,
            child: const Text('Next'),
          ),
        ],
      ),
    );
  }
}

class PrayerStep {
  final String title;
  final String arabicText;
  final String description;
  final String imageAsset;
  final String audioAsset;

  PrayerStep({
    required this.title,
    required this.arabicText,
    required this.description,
    required this.imageAsset,
    required this.audioAsset,
  });
}
