import 'package:flutter/material.dart';
import '../models/quran_models.dart';
import '../services/quran_service.dart';

class DailyContentScreen extends StatefulWidget {
  const DailyContentScreen({Key? key}) : super(key: key);

  @override
  State<DailyContentScreen> createState() => _DailyContentScreenState();
}

class _DailyContentScreenState extends State<DailyContentScreen> {
  final QuranService _quranService = QuranService();
  DailyContent? _dailyContent;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadDailyContent();
  }

  Future<void> _loadDailyContent() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final dailyContent = await _quranService.getDailyContent();
      
      setState(() {
        _dailyContent = dailyContent;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading daily content: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Inspiration'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadDailyContent,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _errorMessage!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadDailyContent,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_dailyContent == null) {
      return const Center(
        child: Text('No daily content available'),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildVerseOfTheDay(),
          const SizedBox(height: 24),
          _buildHadithOfTheDay(),
        ],
      ),
    );
  }

  Widget _buildVerseOfTheDay() {
    final verse = _dailyContent!.verseOfTheDay;
    
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Verse of the Day',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: Icon(
                    verse.isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: verse.isFavorite ? Colors.red : null,
                  ),
                  onPressed: () {
                    // TODO: Implement favorite functionality
                  },
                ),
              ],
            ),
            const Divider(),
            const SizedBox(height: 8),
            Text(
              verse.arabicText,
              style: const TextStyle(
                fontSize: 24,
                fontFamily: 'Amiri', // Arabic font
                height: 1.5,
              ),
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
            ),
            const SizedBox(height: 16),
            Text(
              verse.translation,
              style: const TextStyle(
                fontSize: 16,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Surah ${verse.surahNumber}, Verse ${verse.verseNumber}',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHadithOfTheDay() {
    final hadith = _dailyContent!.hadithOfTheDay;
    
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Hadith of the Day',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const Divider(),
            const SizedBox(height: 8),
            Text(
              hadith.arabicText,
              style: const TextStyle(
                fontSize: 22,
                fontFamily: 'Amiri', // Arabic font
                height: 1.5,
              ),
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
            ),
            const SizedBox(height: 16),
            Text(
              hadith.englishText,
              style: const TextStyle(
                fontSize: 16,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              '${hadith.collection}, Book ${hadith.bookNumber}, Hadith ${hadith.hadithNumber}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            if (hadith.grade.isNotEmpty)
              Text(
                'Grade: ${hadith.grade}',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
