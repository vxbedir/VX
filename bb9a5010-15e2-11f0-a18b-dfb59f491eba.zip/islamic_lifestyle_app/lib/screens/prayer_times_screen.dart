import 'package:flutter/material.dart';
import '../services/prayer_time_service.dart';
import '../models/prayer_time.dart';

class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({Key? key}) : super(key: key);

  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  final PrayerTimeService _prayerTimeService = PrayerTimeService();
  DailyPrayerTimes? _prayerTimes;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadPrayerTimes();
  }

  Future<void> _loadPrayerTimes() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final prayerTimes = await _prayerTimeService.getPrayerTimes();
      
      setState(() {
        _prayerTimes = prayerTimes;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading prayer times: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Prayer Times'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadPrayerTimes,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _errorMessage!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadPrayerTimes,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_prayerTimes == null) {
      return const Center(
        child: Text('No prayer times available'),
      );
    }

    return Column(
      children: [
        _buildNextPrayerCard(),
        Expanded(
          child: _buildPrayerTimesList(),
        ),
      ],
    );
  }

  Widget _buildNextPrayerCard() {
    final nextPrayer = _prayerTimes!.getNextPrayer();
    final now = DateTime.now();
    final difference = nextPrayer.time.difference(now);
    
    final hours = difference.inHours;
    final minutes = difference.inMinutes % 60;
    
    return Card(
      margin: const EdgeInsets.all(16),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              'Next Prayer',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Text(
              nextPrayer.name,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _formatTime(nextPrayer.time),
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Time remaining: ${hours}h ${minutes}m',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPrayerTimesList() {
    final prayers = _prayerTimes!.getAllPrayers();
    
    return ListView.builder(
      itemCount: prayers.length,
      itemBuilder: (context, index) {
        final prayer = prayers[index];
        final isNext = _prayerTimes!.getNextPrayer().name == prayer.name;
        
        return ListTile(
          title: Text(
            prayer.name,
            style: TextStyle(
              fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          subtitle: Text(_formatDate(prayer.time)),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _formatTime(prayer.time),
                style: TextStyle(
                  fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                ),
              ),
              const SizedBox(width: 8),
              Switch(
                value: prayer.notificationEnabled,
                onChanged: (value) {
                  // TODO: Implement notification toggle
                },
              ),
            ],
          ),
        );
      },
    );
  }

  String _formatTime(DateTime time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}
