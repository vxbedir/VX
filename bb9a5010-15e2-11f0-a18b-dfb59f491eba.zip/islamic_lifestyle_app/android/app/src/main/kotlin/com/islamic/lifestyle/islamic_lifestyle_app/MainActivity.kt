package com.islamic.lifestyle.islamic_lifestyle_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
