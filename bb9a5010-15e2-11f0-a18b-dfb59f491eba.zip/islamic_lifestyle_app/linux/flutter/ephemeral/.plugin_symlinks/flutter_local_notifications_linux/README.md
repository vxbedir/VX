# Flutter Local Notifications Linux plugin

The Linux implementation of [`flutter_local_notifications`](https://pub.dev/packages/flutter_local_notifications).

## Usage

This package is already included as part of the `flutter_local_notifications` package dependency, and will
be included when using `flutter_local_notifications` as normal.
