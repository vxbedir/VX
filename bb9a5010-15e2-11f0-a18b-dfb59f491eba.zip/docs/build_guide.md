# Islamic Lifestyle App - Build and Installation Guide

## Project Overview
The Islamic Lifestyle App is a comprehensive mobile application designed to assist Muslims in their daily religious practices. It includes prayer times, Qibla direction, Quran access, daily Islamic content, Salah guidance, and a Dhikr counter.

## Features
1. **Prayer Times and Notifications**
   - Automatic prayer time calculation based on location
   - Customizable notifications for each prayer
   - Daily prayer schedule view

2. **Qibla Direction (Compass)**
   - Accurate Qibla direction using device sensors
   - Kaaba visualization at compass needle tip
   - Location-based calculations

3. **Daily Content**
   - Verse of the Day from the Quran
   - Hadith of the Day from authentic collections
   - Beautifully formatted display

4. **Full Quran Access**
   - Complete Quran text in Arabic
   - Turkish and English translations
   - Bookmark and favorites system
   - Surah and verse navigation

5. **Salah (Prayer) Guidance**
   - Step-by-step prayer instructions
   - Visual guides for prayer positions
   - Audio for prayer recitations
   - Interactive prayer learning interface

6. **Dhikr (Tasbeeh) Counter**
   - Multiple counter support for different dhikrs
   - Save/reset functionality for individual counters
   - Customizable counter targets

## Technical Details
- **Framework**: Flutter 3.19.3
- **Language**: Dart
- **Architecture**: Feature-based with services, models, and screens
- **UI**: Custom Islamic-themed design system with light/dark mode support
- **Responsive**: Adapts to different screen sizes (mobile, tablet, desktop)
- **APIs Used**: AlAdhan API (prayer times), Quran API (Quran text and translations)

## Build Requirements
- Flutter SDK 3.19.3 or later
- Dart SDK 3.3.1 or later
- Android SDK for Android builds
- Xcode 14.0+ for iOS builds (Mac only)
- Git

## Dependencies
- http: ^1.2.2 - For API requests
- flutter_compass: ^0.8.1 - For Qibla compass functionality
- geolocator: ^12.0.0 - For location services
- sqflite: ^2.3.3+1 - For local database
- flutter_local_notifications: ^18.0.1 - For prayer time notifications
- shared_preferences: ^2.2.3 - For storing user preferences
- path_provider: ^2.1.4 - For file management

## Build Instructions

### For Android

1. **Clone the repository**
   ```
   git clone <repository-url>
   cd islamic_lifestyle_app
   ```

2. **Install dependencies**
   ```
   flutter pub get
   ```

3. **Build APK**
   ```
   flutter build apk --release
   ```

4. **Locate the APK**
   The APK will be available at: `build/app/outputs/flutter-apk/app-release.apk`

### For iOS (Mac only)

1. **Clone the repository**
   ```
   git clone <repository-url>
   cd islamic_lifestyle_app
   ```

2. **Install dependencies**
   ```
   flutter pub get
   ```

3. **Build iOS app**
   ```
   flutter build ios --release
   ```

4. **Open in Xcode**
   ```
   open ios/Runner.xcworkspace
   ```

5. **In Xcode:**
   - Select a development team in the Signing & Capabilities tab
   - Select a device or simulator
   - Build and run the app

### For TestFlight (iOS)

1. Follow steps 1-3 from the iOS build instructions
2. In Xcode, configure App Store Connect
3. Upload the build to TestFlight through Xcode

## Installation Instructions

### Android
1. Enable installation from unknown sources in your device settings
2. Copy the APK file to your Android device
3. Tap on the APK file to install
4. Grant required permissions when prompted

### iOS
1. Use TestFlight to install the app (recommended)
2. Alternatively, use Xcode to install directly to a connected device

## Required Permissions
- **Location**: For prayer time calculations and Qibla direction
- **Notifications**: For prayer time alerts
- **Storage**: For storing Quran text and user preferences

## Troubleshooting
- If prayer times are incorrect, check your location settings
- If Qibla compass is inaccurate, calibrate your device's compass
- If notifications don't work, check notification permissions

## Support
For any issues or questions, please contact the development team at support@islamic-lifestyle-app.com
