# Islamic Lifestyle App - User Guide

## Introduction
Welcome to the Islamic Lifestyle App! This comprehensive application is designed to assist Muslims in their daily religious practices. This guide will help you understand and use all the features available in the app.

## Getting Started

### Installation
Please refer to the Build Guide document for detailed installation instructions for both Android and iOS devices.

### Initial Setup
When you first launch the app, you'll need to:
1. Grant location permissions (for prayer times and Qibla direction)
2. Grant notification permissions (for prayer time alerts)
3. Select your preferred calculation method for prayer times

## Features

### Prayer Times
The Prayer Times feature provides accurate prayer times based on your current location.

**How to use:**
- The main screen displays all five daily prayers plus sunrise
- The next prayer is highlighted with a countdown timer
- Tap the switch next to each prayer to enable/disable notifications
- Pull down to refresh and update prayer times based on your current location

**Settings:**
- Access settings by tapping the gear icon
- Change calculation method (Hanafi, Shafi, etc.)
- Adjust notification sound preferences
- Set time adjustments if needed

### Qibla Direction
The Qibla compass helps you find the direction of the Kaaba in Mecca for prayer.

**How to use:**
- Hold your device flat and level
- The compass needle with the Kaaba icon will point toward the Qibla
- The degrees display shows the exact angle
- Tap the refresh button to recalibrate based on your current location

**Tips:**
- For best accuracy, calibrate your device's compass by moving it in a figure-8 pattern
- Keep away from magnetic objects that may interfere with the compass

### Daily Content
The Daily Content feature provides daily inspiration with a verse from the Quran and a Hadith.

**How to use:**
- Content refreshes automatically each day
- Swipe between Verse of the Day and Hadith of the Day
- Tap the bookmark icon to save favorites
- Tap the share icon to share content with others

### Quran Browser
Access the complete Quran with translations in Turkish and English.

**How to use:**
- Browse the list of Surahs
- Tap any Surah to read its verses
- Use the language selector to switch between translations
- Bookmark verses by tapping the bookmark icon
- Access your bookmarks from the bookmarks tab

**Navigation:**
- Swipe left/right to move between pages
- Use the search icon to find specific verses
- Tap the chapter selector to jump to a specific Surah

### Salah Guidance
Learn how to perform Salah (prayer) with step-by-step instructions.

**How to use:**
- Navigate through prayer steps using the next/previous buttons
- View the correct position for each step
- Read the Arabic text and translation for each recitation
- Tap the play button to hear the audio pronunciation
- Use the step indicator at the top to jump to specific steps

### DhikrMatic (Tasbeeh Counter)
Keep track of your dhikr (remembrance of Allah) recitations.

**How to use:**
- Tap the large circle button to count each recitation
- View your progress toward the target count
- Reset counters by selecting "Reset" from the menu
- Add new counters by tapping the "+" icon
- Edit existing counters by selecting "Edit" from the menu

**Customization:**
- Set custom names and Arabic text for each dhikr
- Set custom target counts
- Rearrange counters by long-pressing and dragging

## Settings and Preferences

### Theme Settings
- Toggle between light and dark mode in the settings
- The app will also follow your system theme by default

### Language Settings
- Change the app interface language
- Adjust Quran translation language preferences

### Notifications
- Customize notification sounds for each prayer
- Set vibration preferences
- Enable/disable notifications for specific prayers

## Troubleshooting

### Prayer Times Issues
- Ensure location permissions are granted
- Check that your device time and timezone are correct
- Verify the calculation method matches your local convention

### Qibla Compass Issues
- Calibrate your device's compass
- Keep away from magnetic interference
- Ensure location permissions are granted

### App Performance
- Close other apps running in the background
- Ensure you have sufficient storage space
- Keep the app updated to the latest version

## Privacy and Data
- The app uses your location only for prayer times and Qibla direction
- No personal data is collected or shared with third parties
- All preferences and favorites are stored locally on your device

## Support and Feedback
For support or to provide feedback, please contact us at support@islamic-lifestyle-app.com

Thank you for using the Islamic Lifestyle App. May it assist you in your daily Islamic practices.
